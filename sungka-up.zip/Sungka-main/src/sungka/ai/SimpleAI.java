package sungka.ai;

import sungka.core.SungkaGame;
import sungka.model.Player;
import sungka.model.Pit;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Simple AI with configurable difficulty levels.
 */
public class SimpleAI {
    public enum Difficulty { EASY, MEDIUM, HARD }

    private final Random rnd = new Random();
    private final Difficulty difficulty;

    public SimpleAI(Difficulty d) { this.difficulty = d; }

    public int chooseMove(SungkaGame game, Player ai) {

        // Collect non-empty pits
        List<Integer> candidates = new ArrayList<>();
        for (int i = ai.getStart(); i <= ai.getEnd(); i++) {
            Pit p = game.board[i];
            if (p.getStones() > 0) candidates.add(i);
        }
        if (candidates.isEmpty()) return -1;

        if (difficulty == Difficulty.EASY) {
            // random non-empty pit
            return candidates.get(rnd.nextInt(candidates.size()));
        }

        // For MEDIUM and HARD, evaluate moves using a light heuristic using preview
        int best = -1;
        double bestScore = Double.NEGATIVE_INFINITY;
        for (int idx : candidates) {
            double score = 0.0;
            List<Integer> seq = game.previewSowSequence(idx);
            if (seq.isEmpty()) continue;
            int last = seq.getLast();

            // landing in house is good
            if (last == ai.getHouseIndex()) score += 8.0;

            // estimate capture: if landing on own empty pit opposite has stones
            if (ai.ownsPit(last) && !game.board[last].isHouse() && game.board[last].getStones() == 0) {
                int opposite = 14 - last;
                if (opposite >= 0 && game.board[opposite].getStones() > 0) score += 12.0;
            }

            // count how many stones would go into our house (times house index appears in seq)
            int houseHits = 0;
            for (int d : seq) if (d == ai.getHouseIndex()) houseHits++;
            score += houseHits * 3.0;

            // prefer moves that leave more stones on our side (rough heuristic)
            int stonesMoved = seq.size();
            score += 0.1 * stonesMoved;

            // HARD adds slight deeper bias towards larger resulting house count
            if (difficulty == Difficulty.HARD) score *= 1.0 + (Math.log(1 + game.board[ai.getHouseIndex()].getStones()) / 20.0);

            // small random tie-breaker
            score += rnd.nextDouble() * 0.1;

            if (score > bestScore) { bestScore = score; best = idx; }
        }
        if (best != -1) return best;

        // fallback to random choice
        return candidates.get(rnd.nextInt(candidates.size()));
    }
}
