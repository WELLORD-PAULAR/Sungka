package sungka.core;

import sungka.model.Pit;
import sungka.model.Player;
import sungka.powerups.PowerUpManager;
import sungka.powerups.PowerUp;

import java.util.*;

public class SungkaGame {
    public static final int WIN_THRESHOLD = 50;
    // 16 pits: 0..6 small B, 7 house B, 8..14 small A, 15 house A
    public Pit[] board = new Pit[16];
    public final Player playerB, playerA;
    Player current;
    PowerUpManager pum = new PowerUpManager();
    Random rnd = new Random();

    // flags & states for power-ups
    private boolean doubleCapture = false;
    private boolean bonusTurn = false;
    private boolean reverseSowing = false;
    private boolean skipOpponent = false;
    private final Map<Player, Boolean> shielded = new HashMap<>();

    // logging hook for GUI
    private ConsumerLogger logger = (s) -> {};

    public SungkaGame() {
        for (int i = 0; i < 16; i++) {
            if (i == 7 || i == 15) board[i] = new Pit(0, true);
            else board[i] = new Pit(7, false);
        }
        playerB = new Player("Player B", 0, 6, 7);
        playerA = new Player("Player A", 8, 14, 15);
        current = playerA;
        shielded.put(playerA, false);
        shielded.put(playerB, false);

        pum.refillToCap(playerA, board, 3);
        pum.refillToCap(playerB, board, 3);
    }

    public void setLogger(ConsumerLogger l) { this.logger = l; }

    public interface ConsumerLogger { void accept(String s); }

    public void log(String s) { logger.accept(s); }

    // getters
    public Player getCurrent() { return current; }
    public Player getOpponent(Player p) { return p == playerA ? playerB : playerA; }
    public Player getOpponentOfCurrent() { return getOpponent(current); }

    // flags setters
    public void setDoubleCapture(boolean v) { doubleCapture = v; }
    public void setBonusTurn(boolean v) { bonusTurn = v; }
    public void setReverseSowing(boolean v) { reverseSowing = v; }
    public void setSkipOpponent(boolean v) { skipOpponent = v; }
    public void setShieldForPlayer(Player p, boolean v) { shielded.put(p, v); }

    public boolean isShielded(Player p) { return shielded.getOrDefault(p, false); }

    public List<Integer> getAdjacentIndices(int pitIdx) {
        List<Integer> out = new ArrayList<>();
        int left = (pitIdx - 1 + 16) % 16;
        int right = (pitIdx + 1) % 16;
        out.add(left); out.add(right);
        return out;
    }

    private int oppositeOf(int pos) { return 14 - pos; }

    public boolean makeMove(int pitIndex) {
        Pit startPit = board[pitIndex];
        if (!current.ownsPit(pitIndex) || startPit.isHouse() || startPit.getStones() == 0) return false;

        int stones = startPit.getStones();
        startPit.setStones(0);

        int pos = pitIndex;
        boolean cc = reverseSowing; // if reversed, use backward sowing
        reverseSowing = false; // consume reverse flag when used

        while (stones > 0) {
            pos = cc ? (pos - 1 + 16) % 16 : (pos + 1) % 16;
            Player opp = getOpponent(current);
            if (pos == opp.getHouseIndex()) continue;
            board[pos].addStone();
            stones--;
        }

        if (pos == current.getHouseIndex()) {
                    log(current.getName() + " landed in house and gets another turn.");
                } else {
                    if (current.ownsPit(pos) && !board[pos].isHouse() && board[pos].getStones() == 1) {
                        int oppPos = oppositeOf(pos);
                        Pit oppPit = board[oppPos];

                        if (!isShielded(getOpponent(current))) {
                    int captured = oppPit.getStones();
                    if (doubleCapture) captured *= 2;
                    int add = captured + 1;
                    board[current.getHouseIndex()].setStones(board[current.getHouseIndex()].getStones() + add);
                    oppPit.setStones(0);
                    board[pos].setStones(0);

                    log(current.getName() + " captured " + captured + " from pit " + oppPos + " (plus 1).");

                    if (oppPit.hasPowerUp()) {
                        if (isShielded(getOpponent(current))) {
                            setShieldForPlayer(getOpponent(current), false);
                            log(getOpponent(current).getName() + "'s shield prevented a power-up from being stolen.");
                        } else {
                            PowerUp stolen = oppPit.getPowerUp();
                            oppPit.clearPowerUp();
                            List<Integer> empties = new ArrayList<>();
                            for (int i = current.getStart(); i <= current.getEnd(); i++) {
                                if (!board[i].hasPowerUp()) empties.add(i);
                            }
                            if (!empties.isEmpty()) {
                                int place = empties.get(rnd.nextInt(empties.size()));
                                board[place].setPowerUp(stolen);
                                log(current.getName() + " stole power-up " + stolen.getName() + " and placed it on pit " + place + ".");
                            } else {
                                board[current.getHouseIndex()].setStones(board[current.getHouseIndex()].getStones() + 1);
                                log(current.getName() + " stole power-up but had no empty pit; converted to +1 shell in house.");
                            }
                        }
                    }
                    doubleCapture = false;
                } else {
                    // opponent shielded — do nothing special
                }
            }
            endTurn(false);
        }
        return true;
    }

    /**
     * Return the sequence of pit indices that would receive stones when sowing
     * from the given pit index, in order. This does not modify game state.
     */
    public List<Integer> previewSowSequence(int pitIndex) {
        List<Integer> seq = new ArrayList<>();
        if (!current.ownsPit(pitIndex)) return seq;
        Pit startPit = board[pitIndex];
        if (startPit.isHouse() || startPit.getStones() == 0) return seq;

        int stones = startPit.getStones();
        int pos = pitIndex;
        boolean cc = reverseSowing; // preview uses current reverse flag but does not consume it

        while (stones > 0) {
            pos = cc ? (pos - 1 + 16) % 16 : (pos + 1) % 16;
            Player opp = getOpponent(current);
            if (pos == opp.getHouseIndex()) continue;
            seq.add(pos);
            stones--;
        }
        return seq;
    }

    public boolean activatePowerUpInPit(int pitIndex) {
        if (!current.ownsPit(pitIndex)) return false;
        Pit p = board[pitIndex];
        if (!p.hasPowerUp()) return false;
        PowerUp pu = p.getPowerUp();
        p.clearPowerUp();
        pu.apply(this, current, pitIndex);
        endTurn(true);
        return true;
    }

    /**
     * Check if a player has reached the win threshold in their house.
     * Returns the winning Player, or null if none.
     */
    public Player checkForWinner() {
        if (board[playerA.getHouseIndex()].getStones() >= WIN_THRESHOLD) return playerA;
        if (board[playerB.getHouseIndex()].getStones() >= WIN_THRESHOLD) return playerB;
        return null;
    }

    private void endTurn(boolean activatedPowerUp) {
        if (bonusTurn) {
            bonusTurn = false;
            log(current.getName() + " keeps turn due to BonusTurn.");
            pum.refillToCap(current, board, 3);
            return;
        }
        Player prev = current;
        if (skipOpponent) {
            skipOpponent = false;
            current = getOpponent(current);
            log(current.getName() + " was skipped.");
            current = getOpponent(current);
        } else {
            current = getOpponent(current);
        }
        pum.refillToCap(prev, board, 3);
    }
}
